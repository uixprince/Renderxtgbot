import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/telegram';
const LOGO_API_BASE = 'https://abbas-logo-ai-gen.vercel.app';
const MAX_RUNTIME_MS = 55_000;
const POLL_INTERVAL_MS = 1_000;
const FAST_WINDOW_ATTEMPTS = 30;
const MAX_CHECK_ATTEMPTS = 120;

async function telegramRequest(endpoint: string, body: Record<string, unknown>, lovableKey: string, telegramKey: string) {
  const response = await fetch(`${GATEWAY_URL}/${endpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${lovableKey}`,
      'X-Connection-Api-Key': telegramKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  return response.json();
}

function getProgressStars(attempts: number): string {
  const percent = Math.min(95, Math.floor((attempts / FAST_WINDOW_ATTEMPTS) * 100));
  const filled = Math.min(5, Math.floor(percent / 20));
  return '★'.repeat(filled) + '☆'.repeat(5 - filled);
}

function getProgressMessage(attempts: number): string {
  const percent = Math.min(95, Math.floor((attempts / FAST_WINDOW_ATTEMPTS) * 100));
  const stars = getProgressStars(attempts);
  return `Generating your logo...\n\n${stars} ${percent}%\n\nPlease wait...`;
}

function formatTimestamp(date: Date): string {
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

Deno.serve(async () => {
  const startTime = Date.now();

  const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
  if (!LOVABLE_API_KEY) return new Response(JSON.stringify({ error: 'LOVABLE_API_KEY not configured' }), { status: 500 });

  const TELEGRAM_API_KEY = Deno.env.get('TELEGRAM_API_KEY');
  if (!TELEGRAM_API_KEY) return new Response(JSON.stringify({ error: 'TELEGRAM_API_KEY not configured' }), { status: 500 });

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  let processed = 0;

  // Loop: keep checking every 5 seconds until time runs out
  while (Date.now() - startTime < MAX_RUNTIME_MS) {

    // Step 1: Start generation for "pending" jobs
    const { data: pendingJobs } = await supabase
      .from('pending_logos')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
      .limit(5);

    for (const job of pendingJobs || []) {
      try {
        await telegramRequest('sendChatAction', {
          chat_id: job.chat_id,
          action: 'upload_photo',
        }, LOVABLE_API_KEY, TELEGRAM_API_KEY);

        const genRes = await fetch(`${LOGO_API_BASE}/gen?prompt=${encodeURIComponent(job.prompt)}`);
        const genData = await genRes.json();

        if (genData.task_id) {
          if (job.status_message_id) {
            await telegramRequest('editMessageText', {
              chat_id: job.chat_id,
              message_id: job.status_message_id,
              text: getProgressMessage(0),
            }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
          }
          await supabase.from('pending_logos').update({
            status: 'checking',
            task_id: genData.task_id,
            updated_at: new Date().toISOString(),
          }).eq('id', job.id);
        } else {
          await supabase.from('pending_logos').update({ status: 'failed', updated_at: new Date().toISOString() }).eq('id', job.id);
          await telegramRequest('sendMessage', { chat_id: job.chat_id, text: 'Logo generation failed. Please try again.' }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
        }
      } catch (e) {
        console.error('Gen error:', e);
        await supabase.from('pending_logos').update({ status: 'failed', updated_at: new Date().toISOString() }).eq('id', job.id);
      }
    }

    // Step 2: Check "checking" jobs
    const { data: checkingJobs } = await supabase
      .from('pending_logos')
      .select('*')
      .eq('status', 'checking')
      .order('created_at', { ascending: true })
      .limit(10);

    if ((!pendingJobs || pendingJobs.length === 0) && (!checkingJobs || checkingJobs.length === 0)) {
      // No work to do, exit early
      break;
    }

    for (const job of checkingJobs || []) {
      try {
        const checkRes = await fetch(`${LOGO_API_BASE}/check?task=${job.task_id}`);
        const checkData = await checkRes.json();

        if (checkData.image_url) {
          const now = new Date();
          const timestamp = formatTimestamp(now);
          const timeTaken = Math.round((now.getTime() - new Date(job.created_at).getTime()) / 1000);

          const text = `Logo ready ✅\n\nPrompt: ${job.prompt}\nTime: ${timeTaken}s\nDate: ${timestamp}\n\nImage URL:\n${checkData.image_url}`;

          await telegramRequest('sendMessage', {
            chat_id: job.chat_id,
            text,
          }, LOVABLE_API_KEY, TELEGRAM_API_KEY);

          if (job.status_message_id) {
            await telegramRequest('deleteMessage', { chat_id: job.chat_id, message_id: job.status_message_id }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
          }

          await supabase.from('pending_logos').update({ status: 'completed', image_url: checkData.image_url, updated_at: new Date().toISOString() }).eq('id', job.id);
          processed++;
        } else {
          const newAttempts = (job.attempts || 0) + 1;

          if (job.status_message_id && newAttempts % 2 === 0) {
            try {
              await telegramRequest('editMessageText', { chat_id: job.chat_id, message_id: job.status_message_id, text: getProgressMessage(newAttempts) }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
            } catch (_) {}
          }

          if (newAttempts >= MAX_CHECK_ATTEMPTS) {
            const statusUrl = job.task_id ? `${LOGO_API_BASE}/check?task=${job.task_id}` : null;
            await supabase
              .from('pending_logos')
              .update({ status: 'failed', attempts: newAttempts, updated_at: new Date().toISOString() })
              .eq('id', job.id);

            const timeoutText = statusUrl
              ? `Still processing on API.\n\nDirect status URL:\n${statusUrl}`
              : 'Timed out, please try again.';

            if (job.status_message_id) {
              await telegramRequest('editMessageText', {
                chat_id: job.chat_id,
                message_id: job.status_message_id,
                text: timeoutText,
              }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
            } else {
              await telegramRequest('sendMessage', {
                chat_id: job.chat_id,
                text: timeoutText,
              }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
            }
          } else {
            await supabase.from('pending_logos').update({ attempts: newAttempts, updated_at: new Date().toISOString() }).eq('id', job.id);
            if (job.status_message_id && newAttempts === FAST_WINDOW_ATTEMPTS) {
              await telegramRequest('editMessageText', {
                chat_id: job.chat_id,
                message_id: job.status_message_id,
                text: 'Generating your logo...\n\n★★★★★ 95%\n\nAlmost done, finalizing...',
              }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
            }
          }
        }
      } catch (e) {
        console.error('Check error:', e);
        const fallbackAttempts = (job.attempts || 0) + 1;

        if (fallbackAttempts >= MAX_CHECK_ATTEMPTS) {
          const statusUrl = job.task_id ? `${LOGO_API_BASE}/check?task=${job.task_id}` : null;
          await supabase
            .from('pending_logos')
            .update({ status: 'failed', attempts: fallbackAttempts, updated_at: new Date().toISOString() })
            .eq('id', job.id);

          await telegramRequest('sendMessage', {
            chat_id: job.chat_id,
            text: statusUrl
              ? `Check request failed repeatedly.\n\nDirect status URL:\n${statusUrl}`
              : 'Check request failed repeatedly. Please try again.',
          }, LOVABLE_API_KEY, TELEGRAM_API_KEY);
        } else {
          await supabase
            .from('pending_logos')
            .update({ attempts: fallbackAttempts, updated_at: new Date().toISOString() })
            .eq('id', job.id);
        }
      }
    }

    // Wait briefly before next check
    await sleep(POLL_INTERVAL_MS);
  }

  return new Response(JSON.stringify({ ok: true, processed }));
});
