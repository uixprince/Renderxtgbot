# Render-ready bot runner

Is package me 2 cheezein hain:
1. `main.py` — Render par long-running worker + health server chalata hai.
2. `current-bot/` — aapke current backend bot code ki exact copy.

## Render setup

- Service type: **Web Service**
- Build command: `pip install -r requirements.txt`
- Start command: `python main.py`

## Required env vars

- `TELEGRAM_POLL_FUNCTION_URL` = aapke backend ka `telegram-poll` function URL
- `LOGO_WORKER_FUNCTION_URL` = optional, agar logo queue bhi chalani ho
- `BACKEND_AUTH_TOKEN` = optional/public auth token agar function auth maange

## Included current bot files

- `current-bot/supabase/functions/telegram-poll/index.ts`
- `current-bot/supabase/functions/telegram-send-worker/index.ts`
- `current-bot/supabase/functions/logo-worker/index.ts`
- `current-bot/supabase/config.toml`

## Local run

```bash
pip install -r requirements.txt
python main.py
```

Health check:
- `GET /`
- `GET /health`
